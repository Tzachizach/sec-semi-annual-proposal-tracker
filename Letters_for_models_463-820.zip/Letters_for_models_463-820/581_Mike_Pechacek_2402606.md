# Letter 581 — Mike Pechacek

- **Date:** 2026-05-29
- **Source:** https://www.sec.gov/comments/S7-2026-15/s7202615-2402606.htm

---

Subject: File No. S7-2026-15
From: Mike Pechacek

Affiliation: 

May 29, 2026

 
I understand the SEC has proposed allowing the public companies to file financial reports twice a year instead of quarterly. I have been a member of an Investment Club for 31 years and we update our stock reports quarterly, based on the quarterly reports. We use these reports to decide which stock/stocks we want to invest in or which stocks we may want to sell. By dropping our information down to twice a year, you would really impact our decision making when we purchase and or sell stocks. We need current information to make informed decisions. We would loose over half of the reviewed, certified financial filings annually if this is approved. It is my understanding that currently, the 10-Q is reviewed by independent auditors, and the CEO and CFO sign it personally and can be held legally accountable for its contents. The voluntary corporate communications that would replace them carry none of that. As I said before, we need good, current information to make good investing decisions, as a small investor, I request that you DO NOT approve this proposal. 

Thank you, 

Mike Pechacek 
Omaha, Nebraska 68157
