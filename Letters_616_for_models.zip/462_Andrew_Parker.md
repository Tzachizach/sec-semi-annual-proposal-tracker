# Letter 462 — Andrew Parker

- **Date:** 2026-05-12
- **Source:** https://www.sec.gov/comments/S7-2026-15/s7202615-774547-2367854_2.pdf
- **PDF:** _meta/pdf_letters/462_Andrew_Parker.pdf

---

Subject: File No. S7-2026-15
From: Andrew Parker

COMMENT LETTER
Re: File No. S7-2026-15 – Proposed Amendments Permitting Optional Semiannual
Reporting
To the Securities and Exchange Commission:
I appreciate the opportunity to provide comments on the proposed rule permitting optional
semiannual reporting for eligible public companies. I am attaching this amended comment
because I did not see an updated comment in relation to the new comment I sent yesterday
after the original one did not post correctly at the time. I made significant updates in the
meantime about when the public intent of the disclosure rules towards material weaknesses as
an early warning sign is not accomplished in practice due to lingering significant deficiencies
and late-changing classification as a significant deficiency.This comment responds specifically
to:
Request for Comment 18: “Would this practice create any new or heightened
investor protection concerns?”
and
Request for Comment 26: “For semiannual filers, what impact would a shift to
semiannual reporting have on: (1) companies’ disclosure controls and procedures,
(2) companies’ internal control over financial reporting, and (3) independent public
accountants’ strategy and approach for the annual audit of companies’ internal
control over financial reporting or financial statements? With semiannual reporting,
is there a potential for a material increase in the risk that material misstatements
(either due to error or fraud) or control deficiencies are not timely detected or
communicated to the independent public accountant thereby limiting potential
remediation of these issues by the issuer? Please provide any data related to these
questions.”
Introduction
There are conditions currently undisclosed to shareholders that would occur in semi-annual
reporting that based on my experience when present generate serious concern for a material
increase in the risk that material misstatements (either due to error or fraud) or control
deficiencies are not timely detected by or communicated to the independent public accountant
thereby limiting potential remediation of these issues by the issuer. Knowledge of these
conditions are based on my discussions I had while I was an external auditor of public
companies. There would be heightened investor protection concerns present that when coupled
with semi-annual reporting indicate to me that semiannual reporting should be restricted to
mostly mature companies that have consistently avoided 1) material revisions, 2) material
misstatements, and 3) ICFR material failures in period-end, occurring without material revisions
or misstatements, often accompanied with lingering significant deficiencies affecting other
material line items/metrics.
In quarterly reporting, emerging growth companies especially with the listed conditions present
benefit from additional feedback as the company continues to grow and from additional practice
performing quarterly close controls. More mature companies with the listed conditions present
benefit from more frequent operation of controls that brings with it increased precision.
Semiannual reporting alone will likely extend the timeline of ICFR control remediation in
period-end FR for some emerging growth companies (EGCs) over a greater number of years
and create lingering issues from material failures in ICFR from my limited experience. Hopefully,
increasing disclosure of these conditions will result in an incentive to improve capital markets
efficiency, governance, and SOX readiness.
A shift to semi-annual reporting under the current disclosure requirements for public companies
with now-undisclosed material revisions in total, material misstatements, or material ICFR
control failures in period-end financial reporting, without material misstatements or revisions, but
accompanied with lingering significant deficiencies materially affecting other material line
items/metrics used to value the company presents serious risks when there is a:
1) A compounding effect of material extraordinary risks to financial reporting from fraud or
operational problems that presents itself as material control failures to period end financial
reporting, occurring often alongside near-material failures in other ICFRs such as operational
controls for material line items/metrics used to value the company at the entity level. Sometimes
these controls are remediated in the last quarter (presenting planning/risk assessment
problems) or still classified as significant deficiencies at year-end without public disclosure of
steps taken to try to remediate them. Companies avoid public disclosure at all contrary to the
publicly listed intent of the rules.1 The effect of current disclosure practices results in companies
1 Currently under PCAOB Auditing Standard 2201 (AS 2201), the mandate for judgment is clear:
"The auditor must evaluate the severity of each control deficiency that comes to his or her attention to
determine whether the deficiencies, individually or in combination, are material weaknesses as of the date
of management's assessment. In planning and performing the audit, however, the auditor is not required
to search for deficiencies that, individually or in combination, are less severe than a material weakness.
The severity of a deficiency depends on -Whether there is a reasonable possibility that the company's
controls will fail to prevent or detect a misstatement of an account balance or disclosure; and
The magnitude of the potential misstatement resulting from the deficiency or deficiencies."
https://pcaobus.org/oversight/standards/auditing-standards/details/AS2201. AS 2 that was adopted prior:
Required auditors to actively search for, evaluate, and report all significant deficiencies. This led to
massive audit costs and forced auditors to evaluate minor, less consequential defects.”
As stated at the time of its release in 2007 “The new version should increase the likelihood that material
weaknesses will serve as an early warning system, rather than merely as after-the-fact acknowledgments
that something has gone wrong. “
https://pcaobus.org/news-events/speeches/speech-detail/statement-on-adoption-of-auditing-standard-no-
5-and-related-proposals_212.
avoiding public reporting of significant deficiencies, including some longstanding issues, that
often occur alongside recent period-end financial reporting control failures under current
disclosure law through classification of these issues as a significant deficiency at year end (not
explicitly required to be disclosed at all sometimes, but disclosure might occur to some
institutional shareholders who know/have opportunity to ask about them). Significant
deficiencies can be widespread in ICFR operational and/or period-end financial reporting
controls at the segment level after an ICFR control material failure is removed from public
disclosure. While the condition alone of an ICFR material failure in period end financial reporting
in my view should prevent semiannual reporting, a significant deficiency that is a near-material
failure in an operational ICFR can linger undisclosed after the period-end financial reporting
control has been removed from public view in disclosures in the 10-K and certainly presents an
additional risk that I think should prevent semi-annual reporting for these companies. This
information is decision useful because conditions listed above may lead to unexpected costs to
investors in material line items like those that could be directly used to value the company in the
event of going concern risk that may appear in the future. Late filing slightly complicates the
picture and rules should also be considered to reduce the burden for certain companies in the
short rather than medium-term which semi-annual reporting might accomplish.
2) A longer lead time until corrective action will be taken in practice towards most now
undisclosed revisions due to the current frequency and precision of account reconciliations,
management quarterly reviews, and inquiry from auditors as compared to semiannual reporting.
Semiannual reporting would give companies, particularly EGCs who might need it, much less
chances over time to put into practice corrective action that sometimes may take a couple years
to get correct. Quarterly reporting entails more frequent and more precise account
reconciliations that often help discover errors in practice, management reviews, and important
conversations quarterly about material balances that prevent surprises with unnecessary
costs/overruns at year end that are common in emerging growth companies with these
conditions present.
These risks are hard for retail investors to assess fully under the current disclosure
requirements, especially with the disclosures made in practice. Coupled with semiannual
reporting, the current disclosure requirements seem very inadequate to protect all investors’
interests. Especially for investors who may buy/sell the stock after the information is released
selectively if at all because as an investor it helps to find disclosure about these topics in an
Based on my experience, I do not think that the disclosure requirements following a material weakness in
financial reporting followed by widespread significant deficiencies in ICFR serve as an early warning
signal and problems with the current disclosure requirements would be made worse with a shift to
semiannual reporting due to the compounding nature of risk from recent period-end ICFR failures and
ICFR significant deficiencies affecting material line items/metrics like those in operational controls. Also a
longer lead time until corrective actions will be taken in practice due to less frequency and precision of
controls like account reconciliations and management reviews for some companies that adopt semiannual
reporting.
easy to compile XBRL format in a 10-K/Q/S to see a complete view of material information
management uses in making important decisions.
I think that narrowing the scope of who will be eligible for semiannual reporting to not include
public companies with these conditions present for at least three years after they are present
will increase capital markets efficiency and decrease the administrative burden on companies
with proper corporate reporting and governance priorities. Decreased comparability and
consistency in information provided by companies and in between years would be a negative
effect to information provided to investors as a result of these conditions.
Conditions That Should Prevent Semi-Annual Reporting
1. Revisions when in total material over a three year period because of the
compounding effect through quarters of most minor errors seen in practice. Minor
errors are often corrected before public disclosure is currently required after a few
attempts at financial reporting controls, like reconciliations, or through a greater
frequency and precision of review, including conversations, as the mistakes tend
to continue to grow larger over time.
Materiality should be considered over at least a three year rolling period to prevent
intentional one year shifts and one-off operational errors leading to an increased
administrative burden that is unproductive to protect investor interests. If revisions are
disclosed in total, as I think it should be, it should then be broken out to de minimis
materiality, just to say you should not be able to disclose separately determined material
components to certain investors in effect as is currently the case for disclosure made
about revisions like some presentation errors.
Not disclosing all de minimis components when total revisions are material would defeat
the principle of all investors including retail investors being provided decision useful
material information to avoid unforeseen risks that will adequately protect their interests.
Important to note important assumptions in de minimis materiality like a lack of detected
illegality and fraud. Also these disclosure should be made considering qualitative factors
like those listed in SEC Staff Accounting Bulletin No. 99 (SAB 99). Disclosures about the
scope of total revisions to retail investors are often not provided in practice since some
may be disclosed exclusively to institutional investors. Total quantitatively would be
decision-useful information provided to retail investors about the company's progress
toward improving corporate governance. Quantitative revisions should at least be
disclosed for all periods when it has forced the change to quarterly from semiannual
reporting in at least one of the comparative years.
Another benefit of this increased disclosure: It will easily allow retail investors to measure
progress towards remediation and achievement towards possible benefits associated
with semiannual reporting like reduced SG&A, instead of allowing companies to
selectively choose which presentation errors will look best together in a press release as
is achieved sometime under current disclosure requirements as conveniently-framed and
conveniently-timed reformation. Accordingly, all investors would be able to hold
management accountable for all decisions with more material information, including
shifts from quarterly to semiannual reporting as well as remediation steps, and whether
they match the investor’s risk profile. Especially when in practice revisions can be used
as an avenue for a convenient boost to qualitatively important short-term Non-GAAP
metrics, including those metrics important to some investors whose interests may not
adequately represent retail investors’.
2. Material Restatements: Important to mention with consideration of qualitative factors
like those listed in SEC Staff Accounting Bulletin No. 99 (SAB 99).
3. Material ICFR control failures in period-end financial reporting, occurring without
material revisions or restatements, and over the next three years near-material
ICFR failures, classified as significant deficiencies. These significant deficiencies
would have to materially affect material line items/metrics to be disclosed.
Undisclosed remedial action presents serious risks especially when near-material
ICFR failures are remediated in the fourth quarter without proper planning and risk
assessment or undisclosed remedial action leads to ongoing classification as a
significant deficiency at year end. Specifically for controls with
completeness/accuracy considerations like: operational controls that could
materially affect material line items/metrics used to value the company now and in
the future, especially in distress sales, bankruptcies, liquidations, or commodity
sell-offs.
Disclosure would also need to address steps taken to improve information technology.
Companies may not want to disclose control remediations affecting material line
items/metrics occurring in the fourth quarter since it could affect their stock price when
significant deficiencies and remediation methods could otherwise just be disclosed to
management and the audit committee only. However, material ICFR control remediation
in the last quarter of the year that is not subject to proper risk assessment including
around completeness/accuracy, walkthroughs, and feedback throughout the year or is
still classified as a significant deficiency at year end, can generally when combined with
recent failures in period end financial reporting present fraud and operational risks that
should be disclosed to shareholders. Both problems indicate semiannual reporting will
not adequately protect investor interests due to compounding effects of material fraud
and operational risk that could be prevented through more frequent and more precise
control operations like reconciliations, quarterly management reviews, and important
auditor inquiry with management about material balances. There is also usually a need
to increase staff after control failures like period-end financial reporting so an increased
administrative burden should not unduly burden companies that may require additional
staff over a medium term, and the company will likely benefit from additional feedback
throughout the year.
Conclusion on Conditions: These conditions contain information that is materially important to
retail investors, often undisclosed, and usually is accompanied with unforeseen results seen
over a length of time which should prevent semiannual reporting due to the nature of
compounding risk and longer lead times in semiannual reporting that as stated above will affect
(1) companies’ disclosure controls and procedures, (2) companies’ implementation and design
of their approach to remediating internal control over financial reporting, and (3) independent
public accountants’ strategy and approach for the annual audit of companies’ internal control
over financial reporting or financial statements
I would like to see conditions on the proposed semi-annual reporting rule or changes to the
disclosure requirements for public companies because it will:
● Increase risk assessment, planning, and feedback throughout the year around potential
ICFR material control failures through more frequent reviews. Possibly encouraging
companies to attempt to remediate their potential material failures in ICFRs early in the
year. Because not doing so until the end and disclosing the steps you took at the very
end that may have not been adequate, demonstrates the company's role in generating
significant waste through poor governance. Poor governance that would be seen initially
in ICFR material failures, next in disclosed remedial steps taken towards significant
deficiencies affecting material line items/metrics, and finally later in unforeseen costs for
investors that may appear.
● Increase disclosure around steps taken to remediate period-end ICFRs material failures
and near-material failures turned into significant deficiencies that may still materially
affect material line items/metrics such as those used to value the company, especially in
distress sales, bankruptcies, liquidations, or commodity sell-offs. Investors should be
given the information that would help them find answers to questions similar to
institutional investors in determining their risk profile. For example steps taken at each
business segment affected should be described if they are actually taken.
Practical Impact on Companies
Excluding companies that exhibit these risky characteristics from semiannual reporting is key to
address concerns that semi-annual reporting will make fraud or operational problems harder to
detect quickly based on my practical experience with following control failures and resulting
impacts to retail investors. Narrowing the rules will also provide additional incentives for
companies to avoid improperly taking advantage of these conditions that are common in
emerging growth companies and promote proper governance practices as well as increased
efficiency from improved incentives like that to improve SOX readiness. Robust implementation
of AI across companies may change the hiring needs of companies who face issues with the
conditions noted in this comment, but hiring at companies still usually does need to occur
regardless, to remediate the issues when these conditions exist. A question I think may take
more experience to answer is whether three years is appropriate to mandate a shift to quarterly
reporting from semi-annual for mature companies given the rate of change at companies with
the rate of AI adoption. Importantly, I think semi-annual reporting will probably extend the
timeline of remediation for emerging growth companies with material failures in ICFR in period
end in practice, along with the chance of associated errors in the meantime.
Companies will likely probably not want to disclose ICFR control failure remediation for
operational controls affecting material line items/metrics occurring in the last quarter of the year
or for near-material failures in ICFRs that are still classified as a significant deficiency at year
end because it could affect their stock price in their view unnecessarily. However, when
accompanied with period end financial reporting ICFR material failures that alone should
disqualify you from semiannual reporting in my view, the listed conditions present an additional
risk that should be disclosed to investors because of the nature of how information goes from
business segments and into the corporate consolidated financial statements.
Quantified Impact on Public Companies
What percentage of emerging growth companies have control failures in ICFR? As of 2017
Among the 1,862 EGC filers, 1,355 provided a management report on internal control over
financial reporting in their most recent annual filing. Of those 1,355 companies, approximately
46% reported material weaknesses. 2
Adverse ICFR Disclosure Rate by company size (FY2022 excerpt)3
● Large Accelerated Filers:
5.8%
● Accelerated Filers:
17.7%
● Non-Accelerated Filers:
38.0%
That is all the publicly available compiled data I could find without industry datasets that could
provide more precise information about the number of companies with material ICFR failures in
period-end that this would affect.
2https://assets.pcaobus.org/pcaob-dev/docs/default-source/economicandriskanalysis/documents/white-pa
per-characteristics-emerging-growth-companies-may-2017.pdf?
3https://www.scribd.com/document/871426339/SOX-404-Disclosures-ANineteen-YearReview?
Regards,
Andrew Parker
